﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace CookieMaker
{
    internal class Cookie
    {
        public BitmapImage CookieImage = new BitmapImage(new Uri("images/cookie.png", UriKind.Relative));
        public int Width = 100;


    }
}
