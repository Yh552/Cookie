﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CookieMaker
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Cookie MyCookie = new Cookie();
        Random MyRand = new Random();
        public MainWindow()
        {
            InitializeComponent();
        }


        // Method that will create some cookie objects

        public void CreateCookie(object sender, RoutedEventArgs e)
        {
            // Create an Image
            Image MyImage = new Image
            {
                Source = MyCookie.CookieImage,
                Width = MyCookie.Width
            };

            // Set top left corner positioning of new cookie
            Canvas.SetLeft(MyImage, MyRand.Next((int)this.ActualWidth));
            Canvas.SetTop(MyImage, MyRand.Next((int)this.ActualHeight));

            //Add the object to the Window
            RootLayer.Children.Add(MyImage);
        }

        private void ClearCookies(object sender, RoutedEventArgs e)
        {
            RootLayer.Children.Clear();
        }
    }
}
